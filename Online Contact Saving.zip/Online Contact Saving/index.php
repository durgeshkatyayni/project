<?php
session_start();
if(!isset($_SESSION['username']))
{
    header('Location: php/login.php');
    exit;
}

if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    $logout=$_POST['logout-btn'];
    if(isset($logout))
    {
        session_unset();
        session_destroy();
        header('Location: php/login.php');
        exit;
    }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home | Online Contact Saving</title>
    <link rel="stylesheet" href="css/index.css">
</head>
<body>
    <div class="container">

        <!-- code for header part is start from here  -->
        <div class="header">
            <div class="header-left">
                <div class="logo">
                    <a href="index.php">Online  Contact  Saving</a>
                </div>
            </div>
            <div class="header-right">
                <form action="index.php" method="POST" class="logout-form">
                    <input type="submit" name="logout-btn" id="logout-btn" value="Log out">
                </form>
                <p><?php echo"".$_SESSION['username'] ?></p>
                <div class="profile-image">
                    <img src="img/user_image/default_icon2.png">
                </div>
            </div>
        </div>

        <!-- code for center part is start from here  -->
        <div class="center-part">
            <div class="center-left">
                <button>
                   <a href="php/create.php">Create new contact</a>
                </button>
            </div>

            <div class="center-right">
                <table class="table-container">
                    <thead>
                        <th>S.no</th>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Delete</th>
                        <th>Update</th>
                    </thead>
                    <tbody>
                        <?php 
                        
                        include "partials/_dbconnect.php";
                        $s_no=$_SESSION['s_no'];
                        
                        $sql="SELECT * FROM `num_records` WHERE `s_no_user` = '$s_no'";

                        $result=mysqli_query($conn, $sql);
                        
                        if (mysqli_num_rows($result)>=1) 
                        {
                            $i=1;
                            while($row=mysqli_fetch_assoc($result))
                            {?>
                                <tr>
                                    <td><?php echo $i; ?></td>
                                    <td><?php echo $row['name']; ?></td>
                                    <td><?php echo $row['number']; ?></td>
                                    <td><?php echo $row['email']; ?></td>
                                    <td class="td-btn">
                                        <button class="delete-btn">
                                            <a href="php/delete.php?id=<?php echo $row['s_no'];?>">Delete</a>
                                        </button>
                                    </td>
                                    <td class="td-btn">
                                        <button class="update-btn">
                                            <a href="php/update.php?id=<?php echo $row['s_no'];?>">Update</a>
                                        </button>
                                    </td>
                                </tr>
                                <?php
                                $i++;
                            }
                        }
                        ?>
                        
                        <!-- <tr>
                            <td>1</td>
                            <td>Durgesh</td>
                            <td>6202671529</td>
                            <td>Durgesh@kumal.com</td>
                            <td>
                                <button class="delete-btn">
                                    <a href="#">Delete</a>
                                </button>
                            </td>
                            <td>
                                <button class="update-btn">
                                    <a href="#">Update</a>
                                </button>
                            </td>
                        </tr> -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>