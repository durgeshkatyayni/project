<?php

if($_SERVER["REQUEST_METHOD"] == "POST")
{
    $mobile=$_POST['mobile'];
    $passwd=$_POST['passwd'];

    include "../partials/_dbconnect.php";

    $sql="SELECT * FROM `user_table` WHERE `mobile` = '$mobile' and `password`='$passwd'";
    $result=mysqli_query($conn, $sql);

    if(mysqli_num_rows($result)>0 && mysqli_num_rows($result)<=1)
    {
        $row=mysqli_fetch_assoc($result);
        echo"Name : ".$row['user_name'];
        
        session_start();
        $_SESSION['username']=$row['user_name'];
        $_SESSION['s_no']=$row['s_no'];

        header("Location: ../index.php");
    }
    else
    {
        echo"user not found";
    }

}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Online Contact Saving</title>
    <link rel="stylesheet" href="../css/login.css">
</head>
<body>
    <div class="container">
        <div class="form-container">
            <div class="form-title">
                <p>Log in</p>
            </div>
            <form action="login.php" method="post" class="main-form-container">
                <div class="form-field">
                    <input type="tel" name="mobile" id="mobile" maxlength="10" minlength="10" placeholder="Mobile" required>
                </div>

                <div class="form-field">
                    <input type="password" name="passwd" id="passwd" maxlength="50" placeholder="Password" required>
                </div>
                <div class="form-field">
                    <input type="submit" name="submit-btn" id="submit-btn" value="Log in">
                </div>
                <div class="form-field">
                    <p>Create an account ? <a href="signup.php">Sign up</a></p>
                </div>
            </form>
        </div>
    </div>
</body>
</html>